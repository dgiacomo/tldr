# newman

> Collection runner for Postman.
> More information: <https://github.com/postmanlabs/newman>.

- Run a collection (from a file):

`newman run {{path/to/collection.json}}`

- Run a collection (from a URL):

`newman run {{https://www.getpostman.com/collections/631643-f695cab7-6878-eb55-7943-ad88e1ccfd65-JsLv}}`
