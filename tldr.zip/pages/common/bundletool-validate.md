# bundletool validate

> Command-line tool to manipulate Android Application Bundles.
> More information: <https://developer.android.com/studio/command-line/bundletool>.

- Verify a bundle and display detailed information about it:

`bundletool validate --bundle={{path/to/bundle.aab}}`
