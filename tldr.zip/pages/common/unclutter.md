# unclutter

> Hides the mouse cursor.
> More information: <https://manned.org/unclutter.1x>.

- Hide mouse cursor after 3 seconds:

`unclutter -idle {{3}}`
