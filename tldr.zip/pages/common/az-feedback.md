# az feedback

> Send feedback to the Azure CLI Team.
> Part of `azure-cli`.
> More information: <https://docs.microsoft.com/cli/azure/reference-index#az_feedback>.

- Send feedback to the Azure CLI Team:

`az feedback`
