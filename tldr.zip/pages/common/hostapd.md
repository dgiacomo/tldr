# hostapd

> Start an access point using a wireless interface.
> More information: <https://w1.fi/hostapd/>.

- Start an access point:

`sudo hostapd {{path/to/hostapd.conf}}`

- Start an access point, forking into the background:

`sudo hostapd -B {{path/to/hostapd.conf}}`
