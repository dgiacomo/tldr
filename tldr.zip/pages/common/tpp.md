# tpp

> Command-Line based presentation tool.
> More information: <https://github.com/cbbrowne/tpp>.

- View a presentation:

`tpp {{filename}}`

- Output a presentation:

`tpp -t {{type}} -o {{outputname}} {{filename}}`
