# automountd

> An automatic mount/unmount daemon for `autofs`. Started on demand by `launchd`.
> It should not be invoked manually.
> More information: <https://www.manpagez.com/man/8/automountd/>.

- Start the daemon:

`automountd`

- Log more details to `syslog`:

`automountd -v`
