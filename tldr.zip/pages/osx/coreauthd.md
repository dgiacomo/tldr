# coreauthd

> A system daemon providing the `LocalAuthentication` framework.
> It should not be invoked manually. See also: `coreautha`.
> More information: <https://www.manpagez.com/man/8/coreauthd/>.

- Start the agent:

`coreauthd`
