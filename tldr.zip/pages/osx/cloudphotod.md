# cloudphotod

> This synchronizes iCloud Photos.
> It should not be invoked manually.
> More information: <https://www.manpagez.com/man/8/cloudphotosd/>.

- Start the daemon:

`cloudphotod`
