# nfcd

> This daemon controls the NFC controller.
> It should not be invoked manually.
> More information: <https://www.manpagez.com/man/8/nfcd/>.

- Start the daemon:

`nfcd`
