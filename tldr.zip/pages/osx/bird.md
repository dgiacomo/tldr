# bird

> This supports the syncing of iCloud and iCloud Drive.
> It should not be invoked manually.
> More information: <https://www.unix.com/man-page/mojave/8/bird/>.

- Start the daemon:

`bird`
