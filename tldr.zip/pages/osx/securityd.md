# securityd

> This manages security contexts and cryptographic operations.
> Works with secd for keychain access.
> It should not be invoked manually.
> More information: <https://www.unix.com/man-page/osx/1/securityd/>.

- Start the daemon:

`securityd`
