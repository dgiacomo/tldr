# coreautha

> A system agent providing the `LocalAuthentication` framework.
> It should not be invoked manually. See also: `coreauthd`.
> More information: <https://www.manpagez.com/man/8/coreautha/>.

- Start the agent:

`coreautha`
