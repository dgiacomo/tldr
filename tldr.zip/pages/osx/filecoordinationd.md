# filecoordinationd

> Coordinates access to files by multiple processes (`NSFileCoordinator`, `NSFilePresenter`).
> It should not be invoked manually.
> More information: <https://www.unix.com/man-page/osx/8/filecoordinationd/>.

- Start the daemon:

`filecoordinationd`
