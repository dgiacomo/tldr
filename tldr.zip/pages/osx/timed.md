# timed

> Service that synchronizes system time (e.g. using NTP).
> It should not be invoked manually.

- Start the daemon:

`timed`
