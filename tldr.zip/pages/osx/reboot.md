# reboot

> Reboot the system.
> More information: <https://ss64.com/osx/reboot.html>.

- Reboot immediately:

`sudo reboot`

- Reboot immediately without gracefully shutting down:

`sudo reboot -q`
